const s="/assets/ghost-mark-tile.png";export{s as g};
