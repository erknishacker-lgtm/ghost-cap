const _="__cap_default_camera__",a="__cap_default_microphone__";export{_ as D,a};
