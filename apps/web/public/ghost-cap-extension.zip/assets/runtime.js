const n=e=>new Promise((r,s)=>{chrome.runtime.sendMessage(e,o=>{if(chrome.runtime.lastError){s(new Error(chrome.runtime.lastError.message??"Message failed"));return}r(o)})});export{n as s};
